import java.util.Scanner;

class Sequence {
  public static void main(String[] args) {

    int i = 1, n = 15 ;
   Scanner scan = new Scanner(System.in);
   System.out.println("Enter the first number and second number");
   int firstTerm = scan.nextInt();
   int secondTerm =  scan.nextInt();
    while (i<= n) {
      System.out.print(firstTerm + " " );
      

      int nextTerm = firstTerm + secondTerm;
      firstTerm = secondTerm;
      secondTerm = nextTerm;

      i++;
    }
  }
}