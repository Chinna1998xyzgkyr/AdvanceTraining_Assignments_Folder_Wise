public class Create_An_Integer_Array_for_18_elements {
	public static void main(String[] args) {
		int arr[]={3,2,4,5,6,4,5,7,3,2,3,4,7,1,2,0,0,0};
		int sum=0;
		for (int i = 0; i < arr.length; i++) {
			sum = sum + arr[i];
		}

	    arr [15]=sum;
        arr [16]=sum/(arr.length-3); 
	    int temp=arr[0];
for (int i = 1; i <=arr.length-2; i++)
 {

	if(temp>=arr[i])

	temp=arr[i];
	}

	arr [17]=temp;

	for(int i=0;i<arr.length; i++)
System.out.println(arr[i]);
